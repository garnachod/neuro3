class Particionado(object):
	"""docstring for Particionado"""
	def __init__(self):
		super(Particionado, self).__init__()

	def generaParticiones(self, instances):
		raise NotImplementedError( "Should have implemented this" )
		